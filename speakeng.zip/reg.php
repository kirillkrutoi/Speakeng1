<?php

/*$host = localhost;
$db = u2389906_SPEAKENG;
$user = u2389906_SPEAKEN;
$password = u2389906_SPEAKEN;
$table = users;


$connection = new mysqli($host, $db, $user, $password, $table);

if ($connection -> connect_errno) {
  echo "Failed to connect to MySQL: " . $connection -> connect_error;
  exit();
}*/
$EMAIL = $_POST["EMAIL"];
echo $EMAIL;

?>